{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE DeriveAnyClass #-}

module ProductJSON where

import GHC.Generics
import Data.Aeson
    ( FromJSON(parseJSON),
      genericParseJSON,
      defaultOptions,
      withObject,
      (.:),
      (.:?) )

data DrinkType = Frappe | Tea | Espresso | IceCoffee | NonCoffee
    deriving (Show, Generic, Eq)

data PastryType = WithFilling | WithoutFilling
    deriving (Show, Generic)

data Additive = Additive { addName :: String, addPrice :: Int }
    deriving (Show, Read, Eq, Generic, FromJSON)

data Filling = Filling { fillName :: String, fillPrice :: Int }
    deriving (Show, Read, Eq, Generic, FromJSON)

data Product = Drink { drinkType :: DrinkType, drinkName :: String, drinkPrice :: Int }
             | Pastry { pastryType :: PastryType, pastryName :: String, pastryPrice :: Int }
             | AdditiveProduct Additive
             | FillingProduct Filling
    deriving (Show, Generic, Eq)

instance FromJSON DrinkType where
    parseJSON = genericParseJSON defaultOptions

instance FromJSON PastryType where
    parseJSON = genericParseJSON defaultOptions

instance Read DrinkType where
    readsPrec _ value = case value of
        "Frappe"    -> [(Frappe, "")]
        "Tea"       -> [(Tea, "")]
        "Espresso"  -> [(Espresso, "")]
        "IceCoffee" -> [(IceCoffee, "")]
        "NonCoffee" -> [(NonCoffee, "")]
        _           -> []

instance Read PastryType where
    readsPrec _ value = case value of
        "WithFilling"    -> [(WithFilling, "")]
        "WithoutFilling" -> [(WithoutFilling, "")]
        _                -> []

instance Eq PastryType where
    WithFilling == WithFilling = True
    WithoutFilling == WithoutFilling = True
    _ == _ = False

instance FromJSON Product where
    parseJSON = withObject "Product" $ \o -> do
        mDrinkType <- o .:? "drinkType"
        mPastryType <- o .:? "pastryType"
        case (mDrinkType, mPastryType) of
            (Just dt, Nothing) -> Drink dt <$> o .: "drinkName" <*> o .: "drinkPrice"
            (Nothing, Just pt) -> Pastry pt <$> o .: "pastryName" <*> o .: "pastryPrice"
            _ -> fail "Invalid product"
