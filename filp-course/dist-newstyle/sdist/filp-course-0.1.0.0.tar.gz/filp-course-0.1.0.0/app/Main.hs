{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE DeriveAnyClass #-}

module Main (main) where

import System.IO()
import Text.Read (readMaybe)
import GHC.Generics
import Data.Aeson
import qualified Data.ByteString.Lazy as B
import Text.Parsec
import Text.Parsec.String
import ProductJSON

data DrinkType = Frappe | Tea | Espresso | IceCoffee | NonCoffee
    deriving (Show, Generic, Eq)

data PastryType = WithFilling | WithoutFilling
    deriving (Show, Generic)

data Additive = Additive { addName :: String, addPrice :: Int }
    deriving (Show, Read, Eq, Generic, FromJSON)

data Filling = Filling { fillName :: String, fillPrice :: Int }
    deriving (Show, Read, Eq, Generic, FromJSON)

data Product = Drink { drinkType :: DrinkType, drinkName :: String, drinkPrice :: Int }
             | Pastry { pastryType :: PastryType, pastryName :: String, pastryPrice :: Int }
             | AdditiveProduct Additive
             | FillingProduct Filling
    deriving (Show, Generic, FromJSON, Eq)

instance FromJSON DrinkType where
    parseJSON = genericParseJSON defaultOptions

instance FromJSON PastryType where
    parseJSON = genericParseJSON defaultOptions

instance Read DrinkType where
    readsPrec _ value = case value of
        "Frappe"    -> [(Frappe, "")]
        "Tea"       -> [(Tea, "")]
        "Espresso"  -> [(Espresso, "")]
        "IceCoffee" -> [(IceCoffee, "")]
        "NonCoffee" -> [(NonCoffee, "")]
        _           -> []

instance Read PastryType where
    readsPrec _ value = case value of
        "WithFilling"    -> [(WithFilling, "")]
        "WithoutFilling" -> [(WithoutFilling, "")]
        _                -> []

instance Eq PastryType where
    WithFilling == WithFilling = True
    WithoutFilling == WithoutFilling = True
    _ == _ = False

instance FromJSON Product where
    parseJSON = withObject "Product" $ \o -> do
        mDrinkType <- o .:? "drinkType"
        mPastryType <- o .:? "pastryType"
        case (mDrinkType, mPastryType) of
            (Just dt, Nothing) -> Drink dt <$> o .: "drinkName" <*> o .: "drinkPrice"
            (Nothing, Just pt) -> Pastry pt <$> o .: "pastryName" <*> o .: "pastryPrice"
            _ -> fail "Invalid product"

parseMenu :: String -> Either ParseError [Product]
parseMenu = parse menuParser ""

menuParser :: Parser [Product]
menuParser = do
    _ <- string "["
    products <- many productParser
    _ <- string "]"
    return products

productParser :: Parser Product
productParser = do
    _ <- spaces
    prodType <- read <$> many1 letter
    _ <- spaces
    prodName <- many1 (noneOf "',")
    _ <- spaces
    prodPrice <- read <$> many1 digit
    _ <- spaces
    _ <- char ',' <|> char ']'
    return $ case prodType of
        "Drink"   -> Drink Frappe prodName prodPrice
        "Tea"     -> Drink Tea prodName prodPrice
        "Espresso"-> Drink Espresso prodName prodPrice
        "IceCoffee"-> Drink IceCoffee prodName prodPrice
        "NonCoffee"-> Drink NonCoffee prodName prodPrice
        "Pastry"  -> Pastry (if prodName `elem` ["Tiramisu", "Panna Cotta", "Prague Lux"] then WithoutFilling else WithFilling) prodName prodPrice
        "Additive" -> AdditiveProduct $ Additive prodName prodPrice
        "Filling"  -> FillingProduct $ Filling prodName prodPrice
        _         -> error "Invalid product type"

-- Функция выбора напитка
chooseDrink :: [Product] -> IO Product
chooseDrink menu = do
    putStrLn "Выберите тип напитка:"
    putStrLn "1. Фраппе"
    putStrLn "2. Чай"
    putStrLn "3. Эспрессо"
    putStrLn "4. Кофе со льдом"
    putStrLn "5. Не кофе"
    choice <- getLine
    let drinkType = case choice of
            "1" -> Frappe
            "2" -> Tea
            "3" -> Espresso
            "4" -> IceCoffee
            "5" -> NonCoffee
            _   -> error "Неверный выбор"
    let drinkOptions = filter (\(Drink t _ _) -> t == drinkType) menu
    printOptions drinkOptions
    drinkChoice <- getLine
    case readMaybe drinkChoice of
        Just drink -> return drink
        Nothing    -> do
            putStrLn "Неверный выбор. Пожалуйста, выберите существующий напиток."
            chooseDrink menu

-- Функция выбора выпечки
choosePastry :: [Product] -> IO Product
choosePastry menu = do
    putStrLn "Выберите тип выпечки:"
    putStrLn "1. С начинкой"
    putStrLn "2. Без начинки"
    choice <- getLine
    let pastryType = case choice of
            "1" -> WithFilling
            "2" -> WithoutFilling
            _   -> error "Неверный выбор"
    let pastryOptions = filter (\(Pastry t _ _) -> t == pastryType) menu
    printOptions pastryOptions
    pastryChoice <- getLine
    case readMaybe pastryChoice of
        Just pastry -> return pastry
        Nothing     -> do
            putStrLn "Неверный выбор. Пожалуйста, выберите существующую выпечку."
            choosePastry menu

-- Вспомогательная функция для вывода опций
printOptions :: [Product] -> IO ()
printOptions options = mapM_ (\(index, option) -> putStrLn $ show index ++ ". " ++ show option) (zip [1..] options)

-- Основная функция заказа
main :: IO ()
main = do
    putStrLn "Добро пожаловать в нашу кофейню!"
    contents <- B.readFile "src/data.json"
    putStrLn "Содержимое файла data.json:"
    print contents
    case eitherDecode contents of
        Left err -> print err
        Right parsedMenu -> do
            print parsedMenu         
            order <- makeOrder parsedMenu []
            putStrLn "Ваш заказ:"
            printOrder order
            putStrLn $ "Итого: " ++ show (calculateTotal order) ++ " руб."


-- Функция совершения заказа
makeOrder :: [Product] -> [Product] -> IO [Product]
makeOrder menu currentOrder = do
    putStrLn "Желаете заказать напиток или выпечку?"
    putStrLn "1. Напиток"
    putStrLn "2. Выпечка"
    putStrLn "3. Завершить заказ"
    choice <- getLine
    case choice of
        "1" -> do
            drink <- chooseDrink menu
            makeOrder menu (currentOrder ++ [drink])
        "2" -> do
            pastry <- choosePastry menu
            makeOrder menu (currentOrder ++ [pastry])
        "3" -> return currentOrder
        _   -> do
            putStrLn "Неверный выбор. Пожалуйста, выберите 1, 2 или 3."
            makeOrder menu currentOrder

-- Функция вывода заказа
printOrder :: [Product] -> IO ()
printOrder order = mapM_ print order

-- Функция расчета общей стоимости заказа
calculateTotal :: [Product] -> Int
calculateTotal = sum . map calculateItemTotal

-- Функция расчета стоимости отдельного продукта
calculateItemTotal :: Product -> Int
calculateItemTotal (Drink _ _ price) = price
calculateItemTotal (Pastry pastryType _ price) =
    case pastryType of
        WithFilling -> price * 2
        WithoutFilling -> price